(() => {
  const K = "ol_shared";
  const get = () => JSON.parse(localStorage.getItem(K) || "[]");
  const set = (a) => localStorage.setItem(K, JSON.stringify(a));
  const id = () => Math.random().toString(36).slice(2, 10);
  const upd = (pid, fn) => set(get().map((p) => (p.id === pid ? fn(p) : p)));
  const isAdmin = () => Auth.me()?.role === "admin";

  window.Share = {
    all: get,
    avg(p) {
      const v = Object.values(p.ratings || {});
      return v.length ? v.reduce((a, b) => a + b, 0) / v.length : 0;
    },
    count: (p) => Object.keys(p.ratings || {}).length,
    publish(day, title, desc) {
      const m = Auth.me(),
        ex = Data.get().plan[day] || [];
      if (!ex.length) throw "This day has no exercises yet.";
      const a = get();
      a.unshift({
        id: id(),
        authorId: m.id,
        author: m.name,
        title,
        desc,
        created: new Date().toISOString(),
        muscles: [...new Set(ex.map((e) => e.cat))], 
        ex: ex.map(({ name, cat, sets, reps, kg }) => ({ name, cat, sets, reps, kg })),
        ratings: {}, 
        comments: [],
      });
      set(a);
    },
    rate(pid, n) {
      const m = Auth.me(),
        p = get().find((x) => x.id === pid);
      if (!p) return;
      if (p.authorId === m.id) throw "You can't rate your own plan.";
      if (!(n >= 1 && n <= 10)) return;
      upd(pid, (x) => ({ ...x, ratings: { ...x.ratings, [m.id]: n } }));
    },
    comment(pid, text) {
      const m = Auth.me();
      text = text.trim().slice(0, 300);
      if (!text) return;
      upd(pid, (x) => ({
        ...x,
        comments: [
          ...x.comments,
          { id: id(), userId: m.id, name: m.name, text, date: new Date().toISOString() },
        ],
      }));
    },
    delComment(pid, cid) {
      const m = Auth.me();
      upd(pid, (x) => ({
        ...x,
        comments: x.comments.filter(
          (c) => c.id !== cid || (c.userId !== m.id && !isAdmin()),
        ),
      }));
    },
    remove(pid) {
      const m = Auth.me();
      set(get().filter((p) => p.id !== pid || (p.authorId !== m.id && !isAdmin())));
    },
  };
})();
